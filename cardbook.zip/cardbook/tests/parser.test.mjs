// 명함 텍스트 분류기(parseCardText) 회귀 테스트. 실행: node tests/parser.test.mjs
import { readFileSync } from "node:fs";
import assert from "node:assert/strict";

const html = readFileSync(new URL("../index.html", import.meta.url), "utf8");
const js = html.match(/<script>\n([\s\S]*)<\/script>/)[1];
const helpers = js.slice(js.indexOf("const FIELDS"), js.indexOf("// ================= storage"));
const parser = js.slice(js.indexOf("// ================= parser"), js.indexOf("// ================= Gemini"));
const parseCardText = new Function(helpers + parser + "\nreturn parseCardText;")();

const cases = [
  {
    text: `KIAT
한국산업기술진흥원
반도체산업팀
김 정 현 책임
M. 010-3824-8962  T. 02-6009-3860
F. 02-6009-3899
E. jhk1029@kiat.or.kr
06152 서울시 강남구 테헤란로 305
한국기술센터 5F
Designing Innovation`,
    expect: { name: "김정현", company: "한국산업기술진흥원", department: "반도체산업팀", jobTitle: "책임",
      mobile: "010-3824-8962", phone: "02-6009-3860", fax: "02-6009-3899", email: "jhk1029@kiat.or.kr",
      address: "06152 서울시 강남구 테헤란로 305 한국기술센터 5F" }
  },
  {
    text: `산업통상부
에너지정책과
주무관 홍길동
Tel 044-203-1234 Fax 044-203-1235
H.P 010-1111-2222
hong@korea.kr
www.motie.go.kr
세종특별자치시 한누리대로 402`,
    expect: { name: "홍길동", company: "산업통상부", department: "에너지정책과", jobTitle: "주무관",
      mobile: "010-1111-2222", phone: "044-203-1234", fax: "044-203-1235", email: "hong@korea.kr",
      website: "www.motie.go.kr", address: "세종특별자치시 한누리대로 402" }
  },
  {
    text: `(주)대한설비
대표이사 박민수
전북특별자치도 전주시 덕진구 반룡로 109
TEL 063-270-1234 / FAX 063-270-1235
Mobile +82 10 9876 5432`,
    expect: { name: "박민수", company: "(주)대한설비", jobTitle: "대표이사", mobile: "010-9876-5432",
      phone: "063-270-1234", fax: "063-270-1235", address: "전북특별자치도 전주시 덕진구 반룡로 109" }
  },
  { text: "E-mail: hong . gildong @ abc.co.kr", expect: { email: "hong.gildong@abc.co.kr" } }
];

let failed = 0;
for (const [i, c] of cases.entries()) {
  const got = parseCardText(c.text);
  for (const [k, v] of Object.entries(c.expect)) {
    try { assert.equal(got[k], v); }
    catch { failed++; console.error(`case ${i + 1} ${k}: expected "${v}", got "${got[k]}"`); }
  }
}
console.log(failed ? `${failed} mismatch(es)` : `all ${cases.length} cases passed`);
process.exit(failed ? 1 : 0);
