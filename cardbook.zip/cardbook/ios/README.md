# 명함스캔 (CardScanner)

명함을 찍으면 이름·회사·부서·직함·전화·이메일·주소를 자동으로 읽어
앱 안의 **명함첩**에 보관하고 **아이폰 연락처**에도 추가하는 iPhone 앱입니다.

- 글자 인식은 Apple Vision으로 **기기 안에서만** 처리됩니다 (서버·인터넷 불필요, 무료)
- 한국어·영어 명함 지원
- 요구 사항: iOS 17 이상 아이폰, Xcode 16 이상이 설치된 Mac

## 내 아이폰에 설치하기

1. Mac에서 `CardScanner.xcodeproj`를 더블클릭해 Xcode로 엽니다.
2. 왼쪽에서 맨 위 **CardScanner** 프로젝트 → TARGETS **CardScanner** → **Signing & Capabilities** 탭
   - **Team**: 본인 Apple ID 선택 (없으면 *Add an Account…*로 로그인, 무료 계정 가능)
   - Bundle Identifier가 이미 사용 중이라고 나오면 `com.내이름.CardScanner`처럼 바꿉니다.
3. 아이폰을 USB로 연결하고 Xcode 위쪽 기기 목록에서 내 아이폰을 선택합니다.
4. 아이폰: **설정 > 개인정보 보호 및 보안 > 개발자 모드** 켜기 (재시동 필요)
5. Xcode에서 ▶︎(Run) 버튼을 누릅니다.
6. 처음 실행 시 아이폰: **설정 > 일반 > VPN 및 기기 관리**에서 내 개발자 앱을 '신뢰'합니다.

> 무료 Apple ID로 설치하면 **7일 후 앱이 실행되지 않습니다.** 다시 ▶︎를 누르면 연장됩니다.
> 계속 쓰려면 Apple Developer Program(유료) 가입 후 TestFlight/App Store로 배포하세요.

## 사용 방법

- 오른쪽 위 **＋ → 카메라로 스캔**: 명함을 비추면 모서리를 자동 인식해 촬영합니다. *저장* 누르기
- **＋ → 사진에서 가져오기**: 이미 찍어 둔 명함 사진으로도 인식할 수 있습니다.
- 인식 결과 화면에서 틀린 곳을 고친 뒤 **저장** → 명함첩 + (선택) 아이폰 연락처에 저장
- 분류하지 못한 글자는 **메모**에 모아 두니 필요한 내용만 옮기면 됩니다.
- 상세 화면에서 번호를 누르면 바로 전화, 주소를 누르면 지도, 길게 누르면 복사

## 파일 구성

| 파일 | 역할 |
|---|---|
| `CardScannerApp.swift` | 앱 시작점, SwiftData 저장소 연결 |
| `Models/BusinessCard.swift` | 명함 데이터 모델 · 편집용 임시값(CardDraft) |
| `Services/TextRecognizer.swift` | Vision OCR (한국어·영어) |
| `Services/CardParser.swift` | 인식된 줄 → 항목 분류 규칙 (정규식·직함/성씨 사전) |
| `Services/ContactsService.swift` | 아이폰 연락처에 추가 |
| `Views/CardListView.swift` | 명함첩 목록·검색·스캔 시작 |
| `Views/CardEditView.swift` | 인식 결과 확인·수정 |
| `Views/CardDetailView.swift` | 상세·전화/메일/지도·삭제 |
| `Views/DocumentScannerView.swift` | iOS 기본 문서 스캐너 연결 |

## 인식 정확도를 높이려면

- `CardParser.swift`의 `koreanTitles`(직함), `companyKeywords`(회사 키워드)에
  자주 받는 명함의 단어를 추가하면 분류가 더 정확해집니다.
- 이름은 '흔한 성씨로 시작하는 한글 2~3자 중 가장 크게 인쇄된 것'으로 고릅니다.
- 앞뒷면 명함은 앞면(한글면) 한 장만 찍는 것이 가장 정확합니다.

## Mac 없이 설치 파일(.ipa) 만들기

1. GitHub에 새 저장소를 만들고 이 폴더 전체(숨김 폴더 `.github` 포함)를 올립니다.
2. 저장소의 **Actions** 탭 → *Build unsigned IPA* → **Run workflow** (약 5분)
3. 완료된 실행 화면 아래 **Artifacts**에서 `CardScanner-unsigned-ipa`를 내려받아 압축을 풉니다.
4. Windows PC 또는 Mac에 **Sideloadly**(또는 AltStore)를 설치하고, 아이폰을 USB로 연결한 뒤
   `.ipa`를 끌어다 놓고 본인 Apple ID로 로그인해 설치합니다. (Windows는 iTunes 설치 필요)
5. 아이폰: 설정 > 개인정보 보호 및 보안 > **개발자 모드** 켜기,
   설정 > 일반 > VPN 및 기기 관리에서 내 Apple ID 앱을 **신뢰**
6. 무료 Apple ID로 서명한 앱은 **7일마다** 같은 방법으로 다시 설치해야 합니다.
