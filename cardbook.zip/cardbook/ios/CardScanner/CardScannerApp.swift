import SwiftUI
import SwiftData

@main
struct CardScannerApp: App {
    var body: some Scene {
        WindowGroup {
            CardListView()
        }
        .modelContainer(for: BusinessCard.self)
    }
}
