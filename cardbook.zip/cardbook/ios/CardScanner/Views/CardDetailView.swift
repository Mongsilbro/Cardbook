import SwiftUI
import SwiftData

/// 명함 상세 화면: 전화·문자·메일·지도 바로가기, 연락처 추가, 편집, 삭제
struct CardDetailView: View {
    let card: BusinessCard

    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @State private var showEdit = false
    @State private var showImage = false
    @State private var confirmDelete = false
    @State private var message: String?

    var body: some View {
        List {
            if let data = card.imageData, let image = UIImage(data: data) {
                Section {
                    Button { showImage = true } label: {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    .buttonStyle(.plain)
                    .listRowInsets(EdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8))
                }
            }

            Section {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text(card.name.isEmpty ? "이름 없음" : card.name)
                            .font(.title2.bold())
                        if !card.jobTitle.isEmpty {
                            Text(card.jobTitle).foregroundStyle(.secondary)
                        }
                    }
                    if !card.company.isEmpty { Text(card.company) }
                    if !card.department.isEmpty {
                        Text(card.department).foregroundStyle(.secondary)
                    }
                }
                .padding(.vertical, 4)
                .textSelection(.enabled)
            }

            Section("연락처") {
                actionRow("휴대폰", card.mobile, icon: "iphone", url: telURL(card.mobile))
                if !card.mobile.isEmpty, let sms = URL(string: "sms:" + digits(card.mobile)) {
                    Link(destination: sms) {
                        Label("문자 보내기", systemImage: "message")
                    }
                }
                actionRow("전화", card.phone, icon: "phone", url: telURL(card.phone))
                actionRow("팩스", card.fax, icon: "faxmachine", url: nil)
                actionRow("이메일", card.email, icon: "envelope", url: URL(string: "mailto:" + card.email))
                actionRow("웹사이트", card.website, icon: "safari", url: webURL(card.website))
                actionRow("주소", card.address, icon: "map", url: mapURL(card.address))
            }

            if !card.memo.isEmpty {
                Section("메모") {
                    Text(card.memo).textSelection(.enabled)
                }
            }

            Section {
                Button {
                    Task { await addToContacts() }
                } label: {
                    Label(card.savedToContacts ? "아이폰 연락처에 다시 추가" : "아이폰 연락처에 추가",
                          systemImage: "person.crop.circle.badge.plus")
                }
                Button(role: .destructive) {
                    confirmDelete = true
                } label: {
                    Label("명함 삭제", systemImage: "trash")
                }
            } footer: {
                Text("등록일 \(card.createdAt.formatted(date: .long, time: .shortened))"
                     + (card.savedToContacts ? " · 연락처에 저장됨" : ""))
            }
        }
        .navigationTitle(card.name.isEmpty ? "명함" : card.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            Button("편집") { showEdit = true }
        }
        .sheet(isPresented: $showEdit) {
            CardEditView(card: card)
        }
        .fullScreenCover(isPresented: $showImage) {
            ZStack {
                Color.black.ignoresSafeArea()
                if let data = card.imageData, let image = UIImage(data: data) {
                    Image(uiImage: image).resizable().scaledToFit()
                }
            }
            .onTapGesture { showImage = false }
            .overlay(alignment: .topTrailing) {
                Button { showImage = false } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.title)
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(.white, .white.opacity(0.3))
                }
                .padding()
            }
        }
        .confirmationDialog("이 명함을 삭제할까요?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("삭제", role: .destructive) { deleteCard() }
        } message: {
            Text("아이폰 연락처에 추가된 항목은 지워지지 않습니다.")
        }
        .alert("알림", isPresented: Binding(
            get: { message != nil },
            set: { if !$0 { message = nil } }
        )) {
            Button("확인", role: .cancel) {}
        } message: {
            Text(message ?? "")
        }
    }

    // MARK: - 행

    @ViewBuilder
    private func actionRow(_ label: String, _ value: String, icon: String, url: URL?) -> some View {
        if !value.isEmpty {
            Group {
                if let url {
                    Link(destination: url) {
                        LabeledContent {
                            Text(value).multilineTextAlignment(.trailing)
                        } label: {
                            Label(label, systemImage: icon)
                        }
                    }
                } else {
                    LabeledContent {
                        Text(value).multilineTextAlignment(.trailing)
                    } label: {
                        Label(label, systemImage: icon)
                    }
                }
            }
            .contextMenu {
                Button {
                    UIPasteboard.general.string = value
                } label: {
                    Label("복사", systemImage: "doc.on.doc")
                }
            }
        }
    }

    // MARK: - 동작

    private func addToContacts() async {
        do {
            try await ContactsService.add(CardDraft(card: card))
            card.savedToContacts = true
            try? context.save()
            message = "아이폰 연락처에 추가했습니다."
        } catch {
            message = error.localizedDescription
        }
    }

    private func deleteCard() {
        let target = card
        let ctx = context
        dismiss()
        // 화면이 닫힌 뒤 삭제해야 삭제된 데이터를 그리다 생기는 오류를 피할 수 있음
        Task {
            try? await Task.sleep(for: .milliseconds(400))
            ctx.delete(target)
            try? ctx.save()
        }
    }

    // MARK: - URL 도우미

    private func digits(_ s: String) -> String { s.filter { $0.isASCII && $0.isNumber } }

    private func telURL(_ s: String) -> URL? {
        let d = digits(s)
        return d.isEmpty ? nil : URL(string: "tel:" + d)
    }

    private func webURL(_ s: String) -> URL? {
        guard !s.isEmpty else { return nil }
        return URL(string: s.lowercased().hasPrefix("http") ? s : "https://" + s)
    }

    private func mapURL(_ s: String) -> URL? {
        guard let q = s.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return nil }
        return URL(string: "https://maps.apple.com/?q=" + q)
    }
}
