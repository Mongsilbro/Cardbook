import SwiftUI
import SwiftData
import PhotosUI
import VisionKit

/// 인식이 끝나 편집 화면에 넘길 스캔 결과
struct PendingScan: Identifiable {
    let id = UUID()
    let image: UIImage
    let draft: CardDraft
}

/// 첫 화면: 명함첩 목록
struct CardListView: View {
    @Environment(\.modelContext) private var context
    @Query(sort: \BusinessCard.createdAt, order: .reverse) private var cards: [BusinessCard]

    @State private var searchText = ""
    @State private var showScanner = false
    @State private var showPhotoPicker = false
    @State private var photoItem: PhotosPickerItem?
    @State private var pending: PendingScan?
    @State private var isProcessing = false
    @State private var errorMessage: String?

    private var filteredCards: [BusinessCard] {
        searchText.isEmpty ? cards : cards.filter { $0.matches(searchText) }
    }

    var body: some View {
        NavigationStack {
            Group {
                if cards.isEmpty {
                    ContentUnavailableView {
                        Label("저장된 명함이 없습니다", systemImage: "person.crop.rectangle.stack")
                    } description: {
                        Text("명함을 스캔하면 이름·연락처를 자동으로 읽어 정리해 드립니다.")
                    } actions: {
                        Button {
                            startScan()
                        } label: {
                            Label("명함 스캔하기", systemImage: "camera.viewfinder")
                        }
                        .buttonStyle(.borderedProminent)
                        Button("사진에서 가져오기") { showPhotoPicker = true }
                    }
                } else {
                    List {
                        ForEach(filteredCards) { card in
                            NavigationLink(value: card) {
                                CardRow(card: card)
                            }
                        }
                        .onDelete(perform: delete)
                    }
                    .overlay {
                        if filteredCards.isEmpty {
                            ContentUnavailableView.search(text: searchText)
                        }
                    }
                }
            }
            .navigationTitle("명함첩")
            .navigationDestination(for: BusinessCard.self) { card in
                CardDetailView(card: card)
            }
            .searchable(text: $searchText, prompt: "이름, 회사, 전화번호 검색")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button {
                            startScan()
                        } label: {
                            Label("카메라로 스캔", systemImage: "camera.viewfinder")
                        }
                        Button {
                            showPhotoPicker = true
                        } label: {
                            Label("사진에서 가져오기", systemImage: "photo.on.rectangle")
                        }
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                    }
                    .accessibilityLabel("명함 추가")
                }
            }
            .fullScreenCover(isPresented: $showScanner) {
                DocumentScannerView { image in
                    showScanner = false
                    process(image)
                } onCancel: {
                    showScanner = false
                }
                .ignoresSafeArea()
            }
            .photosPicker(isPresented: $showPhotoPicker, selection: $photoItem, matching: .images)
            .onChange(of: photoItem) { _, item in
                guard let item else { return }
                photoItem = nil
                Task {
                    if let data = try? await item.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        process(image)
                    } else {
                        errorMessage = "사진을 불러오지 못했습니다."
                    }
                }
            }
            .sheet(item: $pending) { scan in
                CardEditView(image: scan.image, draft: scan.draft)
            }
            .overlay {
                if isProcessing {
                    ZStack {
                        Color.black.opacity(0.25).ignoresSafeArea()
                        ProgressView("글자 인식 중…")
                            .padding(24)
                            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                    }
                }
            }
            .alert("알림", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("확인", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "")
            }
        }
    }

    private func startScan() {
        if VNDocumentCameraViewController.isSupported {
            showScanner = true
        } else {
            errorMessage = "이 기기에서는 카메라 스캔을 쓸 수 없습니다. '사진에서 가져오기'를 이용해 주세요."
        }
    }

    private func process(_ image: UIImage) {
        isProcessing = true
        Task {
            let normalized = image.normalized(maxDimension: 2000)
            do {
                let lines = try await TextRecognizer.recognize(normalized)
                let draft = CardParser.parse(lines)
                // 스캐너 화면이 완전히 닫힌 뒤 편집 화면을 띄우기 위한 짧은 대기
                try? await Task.sleep(for: .milliseconds(350))
                isProcessing = false
                pending = PendingScan(image: normalized, draft: draft)
            } catch {
                isProcessing = false
                errorMessage = error.localizedDescription
            }
        }
    }

    private func delete(at offsets: IndexSet) {
        let targets = offsets.map { filteredCards[$0] }
        for card in targets { context.delete(card) }
        try? context.save()
    }
}

/// 목록의 한 줄
struct CardRow: View {
    let card: BusinessCard

    var body: some View {
        HStack(spacing: 12) {
            Group {
                if let data = card.imageData, let image = UIImage(data: data) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                } else {
                    Image(systemName: "person.text.rectangle")
                        .font(.title2)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color(.secondarySystemBackground))
                }
            }
            .frame(width: 72, height: 44)
            .clipShape(RoundedRectangle(cornerRadius: 6))

            VStack(alignment: .leading, spacing: 2) {
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text(card.name.isEmpty ? "이름 없음" : card.name)
                        .font(.headline)
                    if !card.jobTitle.isEmpty {
                        Text(card.jobTitle)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
                let org = [card.company, card.department].filter { !$0.isEmpty }.joined(separator: " · ")
                if !org.isEmpty {
                    Text(org)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }
        }
        .padding(.vertical, 2)
    }
}
