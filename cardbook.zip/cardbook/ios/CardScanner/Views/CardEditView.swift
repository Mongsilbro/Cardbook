import SwiftUI
import SwiftData

/// 인식 결과 확인·수정 화면 (새 명함) 또는 기존 명함 편집 화면
struct CardEditView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context

    private let image: UIImage?
    private let existing: BusinessCard?

    @State private var draft: CardDraft
    @State private var saveToContacts: Bool
    @State private var isSaving = false
    @State private var errorMessage: String?

    /// 새로 스캔한 명함
    init(image: UIImage, draft: CardDraft) {
        self.image = image
        self.existing = nil
        _draft = State(initialValue: draft)
        _saveToContacts = State(initialValue: true)
    }

    /// 저장된 명함 편집
    init(card: BusinessCard) {
        self.image = nil
        self.existing = card
        _draft = State(initialValue: CardDraft(card: card))
        _saveToContacts = State(initialValue: false)
    }

    var body: some View {
        NavigationStack {
            Form {
                if let image {
                    Section {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                            .listRowInsets(EdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8))
                    } footer: {
                        Text("자동 인식 결과입니다. 틀린 곳이 있으면 고쳐 주세요.")
                    }
                }

                Section("기본 정보") {
                    field("이름", text: $draft.name)
                    field("회사", text: $draft.company)
                    field("부서", text: $draft.department)
                    field("직함", text: $draft.jobTitle)
                }

                Section("연락처") {
                    field("휴대폰", text: $draft.mobile, keyboard: .phonePad)
                    field("전화", text: $draft.phone, keyboard: .phonePad)
                    field("팩스", text: $draft.fax, keyboard: .phonePad)
                    field("이메일", text: $draft.email, keyboard: .emailAddress)
                    field("웹사이트", text: $draft.website, keyboard: .URL)
                }

                Section("주소") {
                    TextField("주소", text: $draft.address, axis: .vertical)
                        .lineLimit(1...4)
                }

                Section {
                    TextField("메모", text: $draft.memo, axis: .vertical)
                        .lineLimit(2...8)
                } header: {
                    Text("메모")
                } footer: {
                    if existing == nil && !draft.memo.isEmpty {
                        Text("분류하지 못한 글자를 여기에 모아 두었습니다. 필요한 내용은 위 칸으로 옮기세요.")
                    }
                }

                if existing == nil {
                    Section {
                        Toggle("아이폰 연락처에도 저장", isOn: $saveToContacts)
                    } footer: {
                        Text("켜 두면 기본 '연락처' 앱에도 새 연락처로 추가됩니다.")
                    }
                }
            }
            .navigationTitle(existing == nil ? "새 명함" : "명함 편집")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("취소") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    if isSaving {
                        ProgressView()
                    } else {
                        Button("저장") { Task { await save() } }
                            .fontWeight(.semibold)
                            .disabled(draft.isEmpty)
                    }
                }
            }
            .interactiveDismissDisabled(existing == nil)
            .alert("알림", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("확인") { dismiss() }
            } message: {
                Text(errorMessage ?? "")
            }
        }
    }

    @ViewBuilder
    private func field(_ label: String, text: Binding<String>, keyboard: UIKeyboardType = .default) -> some View {
        LabeledContent(label) {
            TextField(label, text: text)
                .multilineTextAlignment(.trailing)
                .keyboardType(keyboard)
                .textInputAutocapitalization(keyboard == .default ? .words : .never)
                .autocorrectionDisabled(keyboard != .default)
        }
    }

    private func save() async {
        isSaving = true
        defer { isSaving = false }

        let card: BusinessCard
        if let existing {
            draft.apply(to: existing)
            card = existing
        } else {
            card = BusinessCard(draft: draft, imageData: image?.jpegData(compressionQuality: 0.75))
            context.insert(card)
        }

        if saveToContacts {
            do {
                try await ContactsService.add(draft)
                card.savedToContacts = true
            } catch {
                try? context.save()
                errorMessage = "명함첩에는 저장했지만 연락처 추가는 실패했습니다.\n\(error.localizedDescription)"
                return
            }
        }

        try? context.save()
        dismiss()
    }
}
