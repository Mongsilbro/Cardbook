import Foundation
import CoreGraphics

/// OCR 결과(줄 목록)를 이름·회사·전화번호 등으로 분류하는 규칙 기반 파서.
/// 한국 명함 형식에 맞춰져 있으며, 분류하지 못한 줄은 메모에 남겨 사용자가 직접 옮길 수 있게 함.
enum CardParser {

    // MARK: - 진입점

    static func parse(_ lines: [RecognizedLine]) -> CardDraft {
        var draft = CardDraft()
        var leftovers: [String] = []
        var koreanNames: [(name: String, score: CGFloat)] = []
        var englishNames: [(name: String, score: CGFloat)] = []
        var lastWasAddress = false

        for line in lines {
            let raw = line.text.trimmed
            guard !raw.isEmpty else { continue }
            var consumed = false

            // 1. 주소 다음 줄의 건물명·층수는 주소에 이어붙임
            if lastWasAddress, raw.matches(Pattern.addressContinuation), extractPhones(from: raw).isEmpty {
                draft.address += " " + raw
                continue
            }
            lastWasAddress = false

            // 2. 이메일
            if raw.contains("@") || raw.contains("＠") {
                let compact = raw.replacingOccurrences(of: "＠", with: "@").replacingOccurrences(of: " ", with: "")
                if let email = compact.firstMatch(Pattern.email) {
                    if draft.email.isEmpty { draft.email = email.lowercased() }
                    consumed = true
                }
            }

            // 3. 전화·휴대폰·팩스 (한 줄에 여러 개가 있을 수 있음)
            for phone in extractPhones(from: raw) {
                consumed = true
                switch phone.kind {
                case .mobile where draft.mobile.isEmpty: draft.mobile = phone.number
                case .fax where draft.fax.isEmpty: draft.fax = phone.number
                case .office where draft.phone.isEmpty: draft.phone = phone.number
                default: break
                }
            }

            // 4. 웹사이트 (이메일 조각은 제외)
            let withoutEmail = raw.split(separator: " ")
                .filter { !$0.contains("@") && !$0.contains("＠") }
                .joined(separator: " ")
            if let site = withoutEmail.firstMatch(Pattern.website) {
                let lower = site.lowercased()
                if draft.website.isEmpty, !draft.email.hasSuffix(lower) { draft.website = lower }
                consumed = true
            }

            // 5. 주소
            if !consumed {
                let stripped = raw.replacingFirstMatch(Pattern.addressLabel, with: "").trimmed
                if isAddress(stripped) {
                    if draft.address.isEmpty {
                        draft.address = stripped
                        lastWasAddress = true
                    } else {
                        leftovers.append(raw)
                    }
                    consumed = true
                }
            }
            if consumed { continue }

            // 6. 직함 분리 → 나머지로 회사·부서·이름 판단
            let (title, rest) = splitTitle(raw)
            if let title, draft.jobTitle.isEmpty { draft.jobTitle = title }
            let remainder = rest.trimmingCharacters(in: Self.separators)
            if remainder.isEmpty { continue }
            let score = line.height * (title != nil ? 1.5 : 1.0) // 직함과 같은 줄이면 이름일 확률 ↑

            if isCompany(remainder) {
                if draft.company.isEmpty { draft.company = remainder }
                else if draft.department.isEmpty { draft.department = remainder }
                else { leftovers.append(raw) }
                continue
            }
            if isDepartment(remainder) {
                if draft.department.isEmpty { draft.department = remainder } else { leftovers.append(raw) }
                continue
            }
            if let name = koreanName(remainder) {
                koreanNames.append((name, score))
                continue
            }
            if isEnglishTitle(remainder) {
                if draft.jobTitle.isEmpty { draft.jobTitle = remainder } else { leftovers.append(raw) }
                continue
            }
            if let name = englishName(remainder) {
                englishNames.append((name, score))
                continue
            }

            // 7. 한 줄에 "부서 이름"처럼 섞여 있는 경우 단어별로 다시 판단
            var unknown: [String] = []
            var classifiedAny = false
            for token in remainder.split(whereSeparator: { $0 == " " || Self.separators.contains($0.unicodeScalars.first!) }).map(String.init) {
                if isDepartment(token), draft.department.isEmpty {
                    draft.department = token; classifiedAny = true
                } else if let name = koreanName(token) {
                    koreanNames.append((name, score)); classifiedAny = true
                } else {
                    unknown.append(token)
                }
            }
            if !classifiedAny {
                leftovers.append(raw)
            } else if !unknown.isEmpty {
                leftovers.append(unknown.joined(separator: " "))
            }
        }

        // 가장 크게 인쇄된 이름 후보를 이름으로 (한글 우선)
        let sortedKorean = koreanNames.sorted { $0.score > $1.score }
        let sortedEnglish = englishNames.sorted { $0.score > $1.score }
        if let best = sortedKorean.first {
            draft.name = best.name
            leftovers += sortedKorean.dropFirst().map(\.name)
            leftovers += sortedEnglish.map(\.name)
        } else if let best = sortedEnglish.first {
            draft.name = best.name
            leftovers += sortedEnglish.dropFirst().map(\.name)
        }

        draft.memo = leftovers.joined(separator: "\n")
        return draft
    }

    // MARK: - 전화번호

    enum PhoneKind { case mobile, office, fax }

    static func extractPhones(from text: String) -> [(kind: PhoneKind, number: String)] {
        guard let regex = try? NSRegularExpression(pattern: Pattern.phone) else { return [] }
        let ns = text as NSString
        var results: [(kind: PhoneKind, number: String)] = []
        var cursor = 0

        for match in regex.matches(in: text, range: NSRange(location: 0, length: ns.length)) {
            // 번호 바로 앞 글자(예: "T.", "Fax", "M", "휴대폰")를 라벨로 사용
            let labelRange = NSRange(location: cursor, length: match.range.location - cursor)
            let label = ns.substring(with: labelRange).lowercased().filter { $0.isLetter }
            cursor = match.range.location + match.range.length

            guard let number = normalizePhone(ns.substring(with: match.range)) else { continue }

            let isFaxLabel = (label.contains("fax") || label.contains("팩스") || label.hasSuffix("f"))
                && !(label.contains("tel") && label.contains("fax"))
            let kind: PhoneKind
            if number.hasPrefix("01") {
                kind = .mobile
            } else if isFaxLabel {
                kind = .fax
            } else {
                kind = .office
            }
            results.append((kind: kind, number: number))
        }
        return results
    }

    /// 숫자만 뽑아 국내 형식(010-1234-5678, 02-123-4567, 1588-1234)으로 정리
    static func normalizePhone(_ raw: String) -> String? {
        var digits = raw.filter { $0.isASCII && $0.isNumber }
        if digits.hasPrefix("82"), digits.count >= 10 { // +82 국제번호
            digits.removeFirst(2)
            if !digits.hasPrefix("0") { digits = "0" + digits }
        }
        if digits.count == 8, !digits.hasPrefix("0") {
            return "\(digits.prefix(4))-\(digits.suffix(4))"
        }
        guard (9...11).contains(digits.count), digits.hasPrefix("0") else { return nil }
        let areaLength = digits.hasPrefix("02") ? 2 : 3
        let area = digits.prefix(areaLength)
        let last = digits.suffix(4)
        let middle = digits.dropFirst(areaLength).dropLast(4)
        guard (3...4).contains(middle.count) else { return nil }
        return "\(area)-\(middle)-\(last)"
    }

    // MARK: - 직함

    static let koreanTitles: [String] = [
        "대표이사", "대표", "부회장", "회장", "부사장", "사장", "전무이사", "전무", "상무이사", "상무",
        "부이사관", "이사관", "이사", "본부장", "사업부장", "실장", "국장", "부장", "차장", "과장",
        "대리", "주임", "사원", "팀장", "파트장", "그룹장", "센터장", "소장", "원장", "지점장",
        "선임연구원", "책임연구원", "수석연구원", "주임연구원", "연구위원", "연구원", "선임", "책임", "수석",
        "매니저", "프로", "주무관", "사무관", "서기관", "기술서기관", "교수", "부교수", "조교수",
        "변호사", "변리사", "회계사", "세무사", "노무사", "기술사", "고문", "위원", "감사", "공학박사", "박사"
    ].sorted { $0.count > $1.count }

    /// 줄에서 직함 단어를 떼어내 (직함, 나머지)로 반환
    static func splitTitle(_ text: String) -> (String?, String) {
        let tokens = text.split(whereSeparator: { $0 == " " || separators.contains($0.unicodeScalars.first!) })
            .map(String.init)
        let titleSet = Set(koreanTitles)
        let found = tokens.filter { titleSet.contains($0) }
        if !found.isEmpty {
            let rest = tokens.filter { !titleSet.contains($0) }.joined(separator: " ")
            return (found.joined(separator: " "), rest)
        }
        // "홍길동과장"처럼 붙어 있는 경우
        let compact = text.replacingOccurrences(of: " ", with: "")
        for title in koreanTitles where compact.hasSuffix(title) && compact.count > title.count {
            let prefix = String(compact.dropLast(title.count))
            if koreanName(prefix) != nil { return (title, prefix) }
        }
        return (nil, text)
    }

    static func isEnglishTitle(_ text: String) -> Bool {
        guard !text.containsHangul, text.split(separator: " ").count <= 6 else { return false }
        return text.matches(Pattern.englishTitle)
    }

    // MARK: - 이름

    private static let surnames = Set("김이박최정강조윤장임한오서신권황안송류유전홍고문양손배백허남심노하곽성차주우구민진나지엄채원천방공현함변염여추도소석선설마길연위표명기반왕금옥육인맹제모탁국어은편용예경봉사부라빈피".map { $0 })
    private static let compoundSurnames = ["남궁", "황보", "제갈", "선우", "독고", "사공", "서문", "동방"]
    private static let nameStopwords: Set<String> = [
        "대표", "본사", "공장", "지사", "지점", "주소", "전화", "팩스", "휴대폰", "홈페이지", "이메일",
        "사무실", "고객센터", "대표번호", "직통", "내선", "명함", "본점", "영업", "기술", "관리", "기획"
    ]

    /// 한글 2~3자(복성은 4자) + 흔한 성씨로 시작하면 이름으로 판단
    static func koreanName(_ text: String) -> String? {
        let compact = text.filter { !$0.isWhitespace && $0 != "·" && $0 != "." }
        guard compact.matches("^[가-힣]{2,4}$"), !nameStopwords.contains(compact) else { return nil }
        if compact.count == 4 {
            return compoundSurnames.contains(where: { compact.hasPrefix($0) }) ? compact : nil
        }
        guard let first = compact.first, surnames.contains(first) else { return nil }
        if compact.count == 3, compact.hasSuffix("시") || compact.hasSuffix("군") { return nil } // 전주시 등
        return compact
    }

    static func englishName(_ text: String) -> String? {
        guard !text.containsHangul, text.count <= 30,
              text.matches("^[A-Z][A-Za-z'.\\-]+([ \\-]+[A-Z][A-Za-z'.\\-]+){1,2}$") else { return nil }
        return text
    }

    // MARK: - 회사·부서·주소

    private static let companyKeywords = [
        "주식회사", "(주)", "㈜", "(유)", "유한회사", "재단법인", "사단법인", "협동조합", "협회", "공사", "공단",
        "그룹", "은행", "증권", "보험", "병원", "의원", "대학교", "연구원", "연구소", "진흥원", "평가원",
        "Co.,", "Co.", "Corp", "Inc", "Ltd", "LLC", "GmbH", "Company", "Corporation"
    ]

    static func isCompany(_ text: String) -> Bool {
        if companyKeywords.contains(where: { text.localizedCaseInsensitiveContains($0) }) { return true }
        let compact = text.replacingOccurrences(of: " ", with: "")
        if compact.matches("(시청|도청|구청|군청|교육청|특별시|광역시|특별자치도|특별자치시)$") { return true }
        // 정부 부처·청 (예: 산업통상부, 조달청, 인사혁신처)
        return compact.count >= 3 && compact.matches("^[가-힣]{2,}(부|청|처|위원회)$")
    }

    static func isDepartment(_ text: String) -> Bool {
        let compact = text.replacingOccurrences(of: " ", with: "")
        guard compact.count <= 25 else { return false }
        if compact.count >= 3,
           compact.matches("(팀|과|본부|사업부|사업단|부문|센터|그룹|파트|담당관)$") { return true }
        if compact.count >= 4, compact.matches("(실|국|단)$") { return true }
        return text.matches("(?i)\\b(team|dept\\.?|department|division|office|lab)$")
    }

    static func isAddress(_ text: String) -> Bool {
        guard text.count >= 6 else { return false }
        if text.matches(Pattern.region) { return true }
        if text.matches("[가-힣0-9]+(로|길)\\s?\\d+") { return true }
        return text.matches("[가-힣]+(시|구|군)\\s") && text.matches("[가-힣]+(동|리|읍|면)\\s?\\d+")
    }

    // MARK: - 패턴

    static let separators = CharacterSet(charactersIn: "/|,·:：()[]").union(.whitespaces)

    enum Pattern {
        static let email = "[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}"
        static let phone = "(?<!\\d)(?:(?:\\+\\s?82|82)[\\s.\\-]*(?:\\(0\\))?[\\s.\\-]*\\d{1,2}|0\\d{1,2}|\\(0\\d{1,2}\\))[\\s.)\\-]*\\d{3,4}[\\s.\\-]*\\d{4}(?!\\d)|(?<!\\d)1[5-9]\\d{2}[\\s.\\-]\\d{4}(?!\\d)"
        static let website = "(?i)\\b(?:https?://)?(?:www\\.)?[a-z0-9\\-]+(?:\\.[a-z0-9\\-]+)*\\.(?:co\\.kr|go\\.kr|or\\.kr|ac\\.kr|re\\.kr|com|net|org|kr|io|biz|info|co)(?:/[^\\s]*)?\\b"
        static let region = "^\\(?\\d{0,5}\\)?\\s*(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충청|충북|충남|전라|전북|전남|경상|경북|경남|제주)"
        static let addressLabel = "(?i)^(주소|본사|공장|사무소|address|addr)\\s*[.:：]?\\s*|^(a|add)\\s*[.:：]\\s*"
        static let addressContinuation = "(\\d+층|\\d+호|빌딩|타워|센터|플라자|오피스|아파트|\\(.*동\\))"
        static let englishTitle = "(?i)\\b(ceo|cto|cfo|coo|president|vice president|director|manager|engineer|researcher|professor|team leader|head of|partner|consultant|designer|developer|specialist|officer|associate|assistant|senior|principal)\\b"
    }
}

// MARK: - 정규식 도우미

extension String {
    func matches(_ pattern: String) -> Bool {
        range(of: pattern, options: .regularExpression) != nil
    }

    func firstMatch(_ pattern: String) -> String? {
        guard let r = range(of: pattern, options: .regularExpression) else { return nil }
        return String(self[r])
    }

    func replacingFirstMatch(_ pattern: String, with replacement: String) -> String {
        guard let r = range(of: pattern, options: .regularExpression) else { return self }
        return replacingCharacters(in: r, with: replacement)
    }

    var containsHangul: Bool { matches("[가-힣]") }
}
