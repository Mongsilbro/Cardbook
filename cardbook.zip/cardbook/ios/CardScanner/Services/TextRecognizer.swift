import UIKit
import Vision

/// OCR로 인식된 한 줄
struct RecognizedLine {
    let text: String
    /// 이미지 높이 대비 글자 높이 (0~1). 글자가 클수록 이름일 가능성이 높음
    let height: CGFloat
    /// 위에서부터의 위치 (0 = 맨 위)
    let top: CGFloat
    let left: CGFloat
}

enum TextRecognizerError: LocalizedError {
    case invalidImage
    case noText

    var errorDescription: String? {
        switch self {
        case .invalidImage: return "이미지를 처리할 수 없습니다."
        case .noText: return "명함에서 글자를 찾지 못했습니다. 밝은 곳에서 다시 찍어보세요."
        }
    }
}

/// Apple Vision 프레임워크로 한국어·영어 글자를 인식 (기기 안에서만 처리, 인터넷 불필요)
enum TextRecognizer {
    static func recognize(_ image: UIImage) async throws -> [RecognizedLine] {
        guard let cgImage = image.cgImage else { throw TextRecognizerError.invalidImage }
        let orientation = CGImagePropertyOrientation(image.imageOrientation)

        let lines: [RecognizedLine] = try await Task.detached(priority: .userInitiated) {
            let request = VNRecognizeTextRequest()
            request.recognitionLevel = .accurate
            request.recognitionLanguages = ["ko-KR", "en-US"]
            request.usesLanguageCorrection = true

            let handler = VNImageRequestHandler(cgImage: cgImage, orientation: orientation, options: [:])
            try handler.perform([request])

            let observations = request.results ?? []
            return observations.compactMap { observation -> RecognizedLine? in
                guard let candidate = observation.topCandidates(1).first else { return nil }
                let box = observation.boundingBox // Vision 좌표계: 왼쪽 아래가 원점
                return RecognizedLine(text: candidate.string,
                                      height: box.height,
                                      top: 1 - box.maxY,
                                      left: box.minX)
            }
            .sorted { a, b in
                abs(a.top - b.top) < 0.015 ? a.left < b.left : a.top < b.top
            }
        }.value

        guard !lines.isEmpty else { throw TextRecognizerError.noText }
        return lines
    }
}

extension CGImagePropertyOrientation {
    init(_ orientation: UIImage.Orientation) {
        switch orientation {
        case .up: self = .up
        case .upMirrored: self = .upMirrored
        case .down: self = .down
        case .downMirrored: self = .downMirrored
        case .left: self = .left
        case .leftMirrored: self = .leftMirrored
        case .right: self = .right
        case .rightMirrored: self = .rightMirrored
        @unknown default: self = .up
        }
    }
}

extension UIImage {
    /// 방향을 바로 세우고 긴 변을 maxDimension 이하로 줄인 이미지
    func normalized(maxDimension: CGFloat) -> UIImage {
        let longest = max(size.width, size.height)
        let scale = longest > maxDimension ? maxDimension / longest : 1
        let target = CGSize(width: (size.width * scale).rounded(), height: (size.height * scale).rounded())
        let format = UIGraphicsImageRendererFormat.default()
        format.scale = 1
        return UIGraphicsImageRenderer(size: target, format: format).image { _ in
            draw(in: CGRect(origin: .zero, size: target))
        }
    }
}
