import Contacts

enum ContactsError: LocalizedError {
    case denied

    var errorDescription: String? {
        "연락처 접근이 허용되지 않았습니다. 설정 > 앱 > 명함스캔 > 연락처에서 허용해 주세요."
    }
}

/// 아이폰 기본 연락처 앱에 새 연락처를 추가
enum ContactsService {
    static func add(_ draft: CardDraft) async throws {
        let store = CNContactStore()
        guard try await store.requestAccess(for: .contacts) else { throw ContactsError.denied }

        let contact = CNMutableContact()
        let (family, given) = splitName(draft.name)
        contact.familyName = family
        contact.givenName = given
        contact.organizationName = draft.company.trimmed
        contact.departmentName = draft.department.trimmed
        contact.jobTitle = draft.jobTitle.trimmed

        var phones: [CNLabeledValue<CNPhoneNumber>] = []
        if !draft.mobile.trimmed.isEmpty {
            phones.append(.init(label: CNLabelPhoneNumberMobile, value: CNPhoneNumber(stringValue: draft.mobile.trimmed)))
        }
        if !draft.phone.trimmed.isEmpty {
            phones.append(.init(label: CNLabelWork, value: CNPhoneNumber(stringValue: draft.phone.trimmed)))
        }
        if !draft.fax.trimmed.isEmpty {
            phones.append(.init(label: CNLabelPhoneNumberWorkFax, value: CNPhoneNumber(stringValue: draft.fax.trimmed)))
        }
        contact.phoneNumbers = phones

        if !draft.email.trimmed.isEmpty {
            contact.emailAddresses = [.init(label: CNLabelWork, value: draft.email.trimmed as NSString)]
        }
        if !draft.website.trimmed.isEmpty {
            contact.urlAddresses = [.init(label: CNLabelWork, value: draft.website.trimmed as NSString)]
        }
        if !draft.address.trimmed.isEmpty {
            let postal = CNMutablePostalAddress()
            postal.street = draft.address.trimmed
            contact.postalAddresses = [.init(label: CNLabelWork, value: postal)]
        }
        // 참고: 연락처 '메모' 필드는 Apple의 별도 승인(entitlement)이 필요해 저장하지 않음

        let request = CNSaveRequest()
        request.add(contact, toContainerWithIdentifier: nil)
        try store.execute(request)
    }

    /// "홍길동" → ("홍", "길동"), "남궁민수" → ("남궁", "민수"), "Gildong Hong" → ("Hong", "Gildong")
    static func splitName(_ name: String) -> (family: String, given: String) {
        let trimmed = name.trimmed
        let noSpace = trimmed.replacingOccurrences(of: " ", with: "")
        if !noSpace.isEmpty, noSpace.matches("^[가-힣]+$") {
            let compound = ["남궁", "황보", "제갈", "선우", "독고", "사공", "서문", "동방"]
            if noSpace.count >= 4, let surname = compound.first(where: { noSpace.hasPrefix($0) }) {
                return (surname, String(noSpace.dropFirst(surname.count)))
            }
            guard noSpace.count >= 2 else { return ("", noSpace) }
            return (String(noSpace.prefix(1)), String(noSpace.dropFirst()))
        }
        let parts = trimmed.split(separator: " ")
        if parts.count >= 2, let last = parts.last {
            return (String(last), parts.dropLast().joined(separator: " "))
        }
        return ("", trimmed)
    }
}
