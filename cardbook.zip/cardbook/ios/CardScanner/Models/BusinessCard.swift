import Foundation
import SwiftData

/// 앱 안의 명함첩에 저장되는 명함 한 장
@Model
final class BusinessCard {
    var name: String = ""
    var company: String = ""
    var department: String = ""
    var jobTitle: String = ""
    var mobile: String = ""
    var phone: String = ""
    var fax: String = ""
    var email: String = ""
    var website: String = ""
    var address: String = ""
    var memo: String = ""
    @Attribute(.externalStorage) var imageData: Data?
    var createdAt: Date = Date.now
    var savedToContacts: Bool = false

    init(draft: CardDraft, imageData: Data?) {
        self.imageData = imageData
        self.createdAt = .now
        draft.apply(to: self)
    }

    /// 검색어가 이름·회사·부서·직함·전화·이메일 중 하나에 포함되는지
    func matches(_ query: String) -> Bool {
        let q = query.trimmingCharacters(in: .whitespaces)
        guard !q.isEmpty else { return true }
        let texts = [name, company, department, jobTitle, email, memo]
        if texts.contains(where: { $0.localizedCaseInsensitiveContains(q) }) { return true }
        let digits = q.filter { $0.isASCII && $0.isNumber }
        guard digits.count >= 3 else { return false }
        return [mobile, phone, fax].contains { $0.filter { $0.isASCII && $0.isNumber }.contains(digits) }
    }
}

/// 편집 화면에서 쓰는 임시 값 (저장 전까지 모델을 건드리지 않기 위함)
struct CardDraft: Equatable {
    var name = ""
    var company = ""
    var department = ""
    var jobTitle = ""
    var mobile = ""
    var phone = ""
    var fax = ""
    var email = ""
    var website = ""
    var address = ""
    var memo = ""

    init() {}

    init(card: BusinessCard) {
        name = card.name
        company = card.company
        department = card.department
        jobTitle = card.jobTitle
        mobile = card.mobile
        phone = card.phone
        fax = card.fax
        email = card.email
        website = card.website
        address = card.address
        memo = card.memo
    }

    func apply(to card: BusinessCard) {
        card.name = name.trimmed
        card.company = company.trimmed
        card.department = department.trimmed
        card.jobTitle = jobTitle.trimmed
        card.mobile = mobile.trimmed
        card.phone = phone.trimmed
        card.fax = fax.trimmed
        card.email = email.trimmed
        card.website = website.trimmed
        card.address = address.trimmed
        card.memo = memo.trimmed
    }

    var isEmpty: Bool {
        [name, company, department, jobTitle, mobile, phone, fax, email, website, address, memo]
            .allSatisfy { $0.trimmed.isEmpty }
    }
}

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
